"""
=============================================================================
MODULE 7: RAJAT SIR SECTION (Section 6) — The Human Section
=============================================================================
GENERATES: fragments/fragment_07_rajat.html

PURPOSE: Most personal section. Warm, trustworthy, not corporate.
  Left: Photo with credential overlay. Right: Personal text + badges.
  Includes the confidentiality promise in a gold-bordered box.
=============================================================================
"""

def generate_rajat_html():
    """Generate the Rajat Sir personal section."""
    
    html = '''
    <!-- ====================================================================
         SECTION 6: RAJAT SIR — The Human Section
         ====================================================================
         WHY: Rajat Sir IS the product. This section must feel warm,
         personal, and trustworthy. Not corporate. Not a coaching bio.
         
         LAYOUT: Two columns — photo left, text right.
         The personal paragraph is EXACT text from the strategy document.
         The confidentiality promise is in a gold-bordered box.
         Four credential badges in a 2x2 grid.
         
         PHOTO: IMG_6287.JPG (at event/speaking) or best quality available.
         Credential strip overlaid at bottom of photo.
         ==================================================================== -->
    <section id="rajat" class="rajat-section">
        <div class="container">
            <div class="rajat-grid">
                
                <!-- LEFT: PHOTO -->
                <div class="rajat-photo-wrapper">
                    <!-- Primary photo: at event/speaking -->
                    <img 
                        src="images/IMG_6287.JPG"
                        alt="Rajat Sir speaking at an event"
                        class="rajat-photo"
                        onerror="this.src='images/RAJAT Sir Image College.jpeg';"
                    >
                    <!-- Gold glow border (CSS) -->
                    <div class="rajat-photo-glow" aria-hidden="true"></div>
                    <!-- Credential strip at bottom of photo -->
                    <div class="rajat-photo-credential-strip">
                        50 Years Old &middot; 28 Years Experience &middot; TEDx Speaker
                    </div>
                </div>

                <!-- RIGHT: PERSONAL CONTENT -->
                <div class="rajat-content">
                    <div class="rajat-label">THE PERSON BEHIND THE SYSTEM</div>
                    <h2 class="rajat-headline">
                        People Call Me<br>
                        <span class="gold-text">Rajat Sir.</span>
                    </h2>
                    
                    <!-- PERSONAL PARAGRAPH — EXACT text from strategy doc -->
                    <!-- WHY: This is Rajat Sir's voice. It must feel like
                         he's talking directly to the reader. Mentions
                         age (50), experience (28 years), vulnerability
                         (sat across an investor, didn't know what to say).
                         This vulnerability builds trust. -->
                    <div class="rajat-paragraph">
                        <p>"I am 50 years old. I have spent 28 years in business — raising funds, closing deals, making mistakes, and learning from them.</p>
                        <p>I know what it feels like to sit across an investor and not know what to say. I know what it feels like to have a great idea and not know who to call.</p>
                        <p>What I offer is not just a system. I am available to you — to hear your fears, discuss your options, and tell you honestly what I see. Founders don't just need a method. They need a senior person they can trust completely.</p>
                        <p>That is what I am here for."</p>
                    </div>

                    <!-- CONFIDENTIALITY PROMISE — Gold bordered box -->
                    <!-- WHY: This is Rajat Sir's most powerful line.
                         "What you share with me stays with me. Always."
                         It addresses the #1 fear founders have: Will my
                         ideas be stolen? This promise removes that fear. -->
                    <div class="confidentiality-box">
                        <div class="confidentiality-icon">&#128274;</div>
                        <p class="confidentiality-text">
                            "What you share with me stays with me. Always."
                        </p>
                        <p class="confidentiality-author">— Rajat Sir</p>
                    </div>

                    <!-- 4 CREDENTIAL BADGES in 2x2 grid -->
                    <!-- WHY: Credibility markers. Each badge is a dark
                         card with an icon and a fact. 2x2 grid is compact. -->
                    <div class="rajat-badges-grid">
                        <div class="rajat-badge">
                            <span class="badge-icon">&#127908;</span>
                            <span class="badge-text">TEDx Speaker</span>
                        </div>
                        <div class="rajat-badge">
                            <span class="badge-icon">&#127970;</span>
                            <span class="badge-text">Consulted Airtel, Honda, IBM, Levers</span>
                        </div>
                        <div class="rajat-badge">
                            <span class="badge-icon">&#128218;</span>
                            <span class="badge-text">150,000+ Professionals Trained</span>
                        </div>
                        <div class="rajat-badge">
                            <span class="badge-icon">&#128640;</span>
                            <span class="badge-text">1,000+ Sessions Delivered</span>
                        </div>
                    </div>

                    <!-- CTA: "Apply to Work with Rajat Sir" -->
                    <!-- WHY: Never "Book a Session" — always "Apply to Work
                         with Rajat Sir". This is a positioning decision from
                         the strategy doc. "Apply" implies selectivity. -->
                    <a 
                        href="#stage0" 
                        class="cta-primary"
                        onclick="event.preventDefault(); alert('In the final version, this opens your personal portal where you complete Stage 0. Demo mode — coming soon.');"
                    >
                        Apply to Work with Rajat Sir &rarr;
                    </a>
                    <p class="rajat-cta-subtext">Rajat Sir personally reviews every application.</p>
                </div>
            </div>
        </div>
    </section>
    <!-- END OF SECTION 6: RAJAT SIR -->
'''
    return html


if __name__ == "__main__":
    import os
    rajat_html = generate_rajat_html()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(base_dir, "..", "fragments", "fragment_07_rajat.html")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(rajat_html)
    print(f"[MODULE 7] Rajat Sir section generated!")
    print(f"[MODULE 7] Size: {len(rajat_html)} characters")